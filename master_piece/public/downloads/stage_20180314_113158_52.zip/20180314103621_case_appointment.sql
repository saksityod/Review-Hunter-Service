/*
Navicat MySQL Data Transfer

Source Server         : MySql Local
Source Server Version : 50636
Source Host           : localhost:3306
Source Database       : review_hunter2

Target Server Type    : MYSQL
Target Server Version : 50636
File Encoding         : 65001

Date: 2018-03-12 20:58:09
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for case_appointment
-- ----------------------------
DROP TABLE IF EXISTS `case_appointment`;
CREATE TABLE `case_appointment` (
  `appointment_id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` int(11) NOT NULL,
  `appointment_type_id` int(11) NOT NULL,
  `appointment_date` datetime NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `supervised_by` bigint(20) DEFAULT NULL COMMENT '???????',
  `is_vdo_product` tinyint(4) NOT NULL,
  `is_vdo_rh` tinyint(4) NOT NULL,
  `is_picture_product` tinyint(4) NOT NULL,
  `is_picture_rh` tinyint(4) NOT NULL,
  `is_meet_doctor` tinyint(4) NOT NULL,
  `remark` varchar(1000) DEFAULT NULL,
  `created_by` varchar(75) NOT NULL,
  `created_dttm` datetime NOT NULL,
  `updated_by` varchar(75) NOT NULL,
  `updated_dttm` datetime NOT NULL,
  PRIMARY KEY (`appointment_id`),
  KEY `appointment_type_case_appointment_fk1` (`appointment_type_id`),
  KEY `doctor_case_appointment_fk` (`doctor_id`),
  KEY `case_case_appointment_fk` (`case_id`),
  CONSTRAINT `appointment_type_case_appointment_fk1` FOREIGN KEY (`appointment_type_id`) REFERENCES `appointment_type` (`appointment_type_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `case_case_appointment_fk` FOREIGN KEY (`case_id`) REFERENCES `patient_case` (`case_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `doctor_case_appointment_fk` FOREIGN KEY (`doctor_id`) REFERENCES `doctor` (`doctor_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
